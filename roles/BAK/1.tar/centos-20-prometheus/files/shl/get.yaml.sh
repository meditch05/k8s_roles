#!/bin/bash

kubectl get configmap/prometheus-server             -n monitoring -o yaml > configmap.prometheus-server.monitoring.yaml
kubectl get deployment.apps/prometheus-server       -n monitoring -o yaml > deployment.prometheus-server.monitoring.yaml
                                              
kubectl get configmap/prometheus-alertmanager       -n monitoring -o yaml > configmap.prometheus-alertmanager.monitoring.yaml
kubectl get deployment.apps/prometheus-alertmanager -n monitoring -o yaml > deployment.prometheus-alertmanager.monitoring.yaml

