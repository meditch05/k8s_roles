#!/bin/bash

# gpu Check
gpu_server=$(kubectl get nodes "-o=custom-columns=NAME:.metadata.name,GPU:.status.allocatable.nvidia\.com/gpu" | grep -v \<none\> | grep -v NAME)
gpu_num=$(kubectl get nodes "-o=custom-columns=NAME:.metadata.name,GPU:.status.allocatable.nvidia\.com/gpu" | grep -v \<none\> | grep -v NAME | wc -l)

#insert node label
if [ $gpu_num -eq 1 ] ; then
  gpu1=$(echo $gpu_server | cut -d " " -f 1)
  kubectl label nodes $gpu1 node-gpu-exporter=true
elif [ $gpu_num -eq 2 ] ; then
  gpu1=$(echo $gpu_server | cut -d " " -f 1)
  gpu2=$(echo $gpu_server | cut -d " " -f 3)
  kubectl label nodes $gpu1 node-gpu-exporter=true
  kubectl label nodes $gpu2 node-gpu-exporter=true
elif [ $gpu_num -eq 3 ] ; then
  gpu1=$(echo $gpu_server | cut -d " " -f 1)
  gpu2=$(echo $gpu_server | cut -d " " -f 3)
  gpu3=$(echo $gpu_server | cut -d " " -f 5)
  kubectl label nodes $gpu1 node-gpu-exporter=true
  kubectl label nodes $gpu2 node-gpu-exporter=true
  kubectl label nodes $gpu3 node-gpu-exporter=true
else
  echo "Please enter no more than 3 GPU servers."
fi

